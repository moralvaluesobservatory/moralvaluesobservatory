"""MFQ-2 profiles against the human reference frame.

What this script does NOT compute (see docs/WITHDRAWN.md): a single nearest
country per system. That claim was produced from one of four prompt variants;
none of the five systems keeps the same nearest country when the variant
changes, and the correlation gap between first and second place ranges from
0.002 to 0.025. Only the *set* of candidate countries is stable.

The central output is `mfq_human_range.csv`: for each foundation, whether the
system's standardized score falls inside or outside the range spanned by the
19 national means, and whether that verdict holds across all four variants.

Scope limit worth stating plainly: this is a range across *national means*, not
across individuals. A system inside this range resembles the span of country
averages, which is much narrower than the span of people. Within-population
ranges require microdata and are the next step, not a result available here.
"""
from __future__ import annotations
import numpy as np
import pandas as pd
from common import (ROOT, RESULTS, FOUNDATIONS, FOUNDATION_MAP,
                    zscore, profile_correlation, range_position)

ENG = ROOT / "data/raw/mfq/english"
ZH = ROOT / "data/raw/mfq/mandarin"
HUMAN = pd.read_csv(ROOT / "data/reference/mfq2_human_reference_frame.csv")
VARIANTS = ["lente_A", "canonica", "lente_B", "lente_C"]
PRIMARY = "canonica"

SYSTEMS = {"Opus 4.8": (ENG / "opus_generations.csv", "opus-4.8"),
           "GPT 5.5": (ENG / "gpt.csv", None),
           "DeepSeek v4 Pro": (ENG / "deepseek.csv", None),
           "GLM 5.2": (ENG / "glm.csv", None),
           "Fable 5": (ENG / "fable.csv", None)}
ZH_FILES = {"Opus 4.8": ZH / "opus.csv", "GPT 5.5": ZH / "gpt.csv",
            "DeepSeek v4 Pro": ZH / "deepseek.csv", "GLM 5.2": ZH / "glm.csv",
            "Fable 5": ZH / "fable.csv"}


def loaded(path, model=None, variant=None):
    d = pd.read_csv(path)
    d = d[d.estado_parseo == "ok"].copy()
    if model is not None and "modelo" in d.columns:
        d = d[d.modelo == model]
    if variant is not None and "variante" in d.columns:
        d = d[d.variante == variant]
    d["score"] = pd.to_numeric(d.score, errors="coerce")
    d["foundation_name"] = d.fundamento.map(FOUNDATION_MAP)
    return d


def profile(d):
    return d.groupby("foundation_name").score.mean().reindex(FOUNDATIONS).to_numpy()


human_z = np.asarray([zscore(r[FOUNDATIONS].astype(float).to_numpy()) for _, r in HUMAN.iterrows()])
human_lo = human_z.min(axis=0)
human_hi = human_z.max(axis=0)

integrity, profiles, range_rows, language_rows = [], [], [], []

for label, (path, model) in SYSTEMS.items():
    everything = loaded(path, model=model)
    integrity.append({"system": label, "language": "English", "dataset": path.name,
                      "rows": len(pd.read_csv(path)), "parse_ok": len(everything),
                      "variants": int(everything.variante.nunique()) if "variante" in everything else 1,
                      "items": int(everything.item_id.nunique())})

    positions = {}
    for variant in VARIANTS:
        d = loaded(path, model=model, variant=variant)
        if d.empty:
            continue
        p = profile(d); z = zscore(p)
        for foundation, raw_value, z_value in zip(FOUNDATIONS, p, z):
            profiles.append({"system": label, "language": "English", "variant": variant,
                             "foundation": foundation, "mean_score": round(float(raw_value), 6),
                             "z_within_profile": round(float(z_value), 6)})
        for j, foundation in enumerate(FOUNDATIONS):
            positions.setdefault(foundation, []).append(range_position(z[j], human_lo[j], human_hi[j]))

    for j, foundation in enumerate(FOUNDATIONS):
        verdicts = positions.get(foundation, [])
        if not verdicts:
            continue
        unique = set(verdicts)
        range_rows.append({
            "system": label, "foundation": foundation,
            "human_z_min": round(float(human_lo[j]), 6),
            "human_z_max": round(float(human_hi[j]), 6),
            "variants_tested": len(verdicts),
            "variants_within": verdicts.count("within"),
            "variants_above": verdicts.count("above"),
            "variants_below": verdicts.count("below"),
            "verdict": verdicts[0] if len(unique) == 1 else "variant_dependent",
            "robust_across_variants": len(unique) == 1})

    english = profile(loaded(path, model=model, variant=PRIMARY))
    mandarin_raw = loaded(ZH_FILES[label])
    integrity.append({"system": label, "language": "Mandarin", "dataset": ZH_FILES[label].name,
                      "rows": len(pd.read_csv(ZH_FILES[label])), "parse_ok": len(mandarin_raw),
                      "variants": int(mandarin_raw.variante.nunique()) if "variante" in mandarin_raw else 1,
                      "items": int(mandarin_raw.item_id.nunique())})
    mandarin = profile(mandarin_raw)
    language_rows.append({
        "system": label,
        "configuration_english": model or "single configuration",
        "configuration_mandarin": str(mandarin_raw.modelo.iloc[0]) if "modelo" in mandarin_raw else "unknown",
        "profile_correlation_en_zh": round(float(profile_correlation(english, mandarin)), 6),
        "mean_abs_z_shift": round(float(np.nanmean(np.abs(zscore(english) - zscore(mandarin)))), 6),
        "same_configuration": bool(("modelo" in mandarin_raw) and model and
                                   str(mandarin_raw.modelo.iloc[0]) == model)})

pd.DataFrame(integrity).to_csv(RESULTS / "mfq_integrity.csv", index=False)
pd.DataFrame(profiles).to_csv(RESULTS / "mfq_profiles.csv", index=False)
pd.DataFrame(range_rows).to_csv(RESULTS / "mfq_human_range.csv", index=False)
pd.DataFrame(language_rows).to_csv(RESULTS / "mfq_language_comparison.csv", index=False)

summary = pd.DataFrame(range_rows)
print(summary.groupby(["system", "verdict"]).size().unstack(fill_value=0).to_string())
print()
print(pd.DataFrame(language_rows).to_string(index=False))
