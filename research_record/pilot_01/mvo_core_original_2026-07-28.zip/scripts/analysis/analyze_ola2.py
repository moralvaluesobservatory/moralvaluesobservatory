"""Wave 2: stated criteria and dilemma choices.

What this script does NOT compute, and why (see docs/WITHDRAWN.md):

  - No declared-versus-chosen correlation. That statistic was computed across
    five aggregated points, one per model family. With n = 5 the interval runs
    from -0.94 to +0.79 and an exact permutation test gives p = 0.60. It
    carried no information and has been withdrawn.
  - No ranking of systems by proportional choice. There are seven binary
    dilemmas; every system's interval spans roughly 0.15 to 0.87 and all of
    them overlap. Differences at this resolution are not measurable.

What it does compute: per-system estimates with intervals that resample whole
items, plus descriptive per-dilemma counts.
"""
from __future__ import annotations
import numpy as np
import pandas as pd
from common import ROOT, RESULTS, SEED, cluster_bootstrap_mean, ci95

RAW = ROOT / "data/raw/ola2"
META = pd.read_csv(ROOT / "data/metadata/ola2_instrument_registry.csv")

FILES = {"Opus 4.8": "opus.csv", "GPT 5.5": "gpt.csv", "DeepSeek v4 Pro": "deepseek.csv",
         "GLM 5.2": "glm.csv", "Fable 5": "fable.csv"}
THREE = {"Opus 4.8": "opus_3option.csv", "GPT 5.5": "gpt_3option.csv",
         "DeepSeek v4 Pro": "deepseek_3option.csv", "GLM 5.2": "glm_3option.csv",
         "Fable 5": "fable_3option.csv"}


def select(label, df):
    return df[df.modelo == "claude-opus-4-8"].copy() if label == "Opus 4.8" else df.copy()


def first_option(value):
    return None if pd.isna(value) else str(value).strip().split()[0]


integrity, estimates, per_dilemma, drift = [], [], [], []

for index, (label, filename) in enumerate(FILES.items()):
    raw = pd.read_csv(RAW / filename)
    d = select(label, raw)
    ok = d[d.estado_parseo == "ok"].copy()
    ok["value_num"] = pd.to_numeric(ok.valor, errors="coerce")
    integrity.append({"system": label, "dataset": filename, "rows": len(d),
                      "parse_ok": int((d.estado_parseo == "ok").sum()),
                      "parse_rate": round(float((d.estado_parseo == "ok").mean()), 6),
                      "unique_items": int(d.item_id.nunique()),
                      "configurations_in_file": int(raw.modelo.nunique())})

    declared = ok[(ok.bloque == "A_declarado_cdjs_largo") & (ok.formato == "escala")].dropna(subset=["value_num"])
    prop = declared[declared.principio.str.startswith("proporcionalidad")].copy()
    equal = declared[declared.principio == "igualdad"].copy()
    observed = float(prop.value_num.mean() - equal.value_num.mean())
    # Difference of two means, each resampled over its own items.
    rng = np.random.default_rng(SEED + index)
    bp = cluster_bootstrap_mean(prop, "item_id", "value_num", seed=SEED + index)
    be = cluster_bootstrap_mean(equal, "item_id", "value_num", seed=SEED + index + 500)
    lo_d, hi_d = ci95(bp - be)

    binary = ok[(ok.bloque == "B_dilema") & (ok.formato == "binario")].merge(
        META[["item_id", "proportional_option", "equality_option", "scenario_label_es"]],
        on="item_id", how="left")
    binary["is_proportional"] = binary.apply(
        lambda r: str(r.valor).strip() == first_option(r.proportional_option), axis=1)
    chosen = float(binary.is_proportional.mean())
    bb = cluster_bootstrap_mean(binary, "item_id", "is_proportional", seed=SEED + index + 900)
    lo_b, hi_b = ci95(bb)

    estimates.append({
        "system": label,
        "declared_proportionality_minus_equality": round(observed, 4),
        "declared_ci_lo": round(lo_d, 4), "declared_ci_hi": round(hi_d, 4),
        "declared_excludes_zero": bool(lo_d > 0 or hi_d < 0),
        "declared_items": int(declared.item_id.nunique()),
        "chosen_proportional_fraction": round(chosen, 4),
        "chosen_ci_lo": round(lo_b, 4), "chosen_ci_hi": round(hi_b, 4),
        "chosen_dilemmas": int(binary.item_id.nunique()),
        "chosen_interval_width": round(hi_b - lo_b, 4)})

    for item_id, g in binary.groupby("item_id"):
        per_dilemma.append({"system": label, "item_id": item_id,
                            "scenario_label_es": g.scenario_label_es.iloc[0],
                            "proportional_fraction": round(float(g.is_proportional.mean()), 4),
                            "generations": len(g)})

# ------------------------------------------------ version-to-version change
# Paired by item, which is the correct design: the same items are administered
# to each snapshot. Bonferroni-adjusted for the three transitions.
from scipy import stats  # noqa: E402

opus = pd.read_csv(RAW / "opus.csv")
ok = opus[opus.estado_parseo == "ok"].copy()
ok["value_num"] = pd.to_numeric(ok.valor, errors="coerce")
scale = ok[ok.formato == "escala"].dropna(subset=["value_num"])
per_item = scale.groupby(["modelo", "item_id"]).value_num.mean().unstack(0)
versions = sorted(per_item.columns)
alpha = 0.05 / max(len(versions) - 1, 1)
for a, b in zip(versions[:-1], versions[1:]):
    pair = per_item[[a, b]].dropna()
    diff = pair[b] - pair[a]
    n = len(diff); sd = float(diff.std(ddof=1))
    se = sd / np.sqrt(n)
    t_crit = float(stats.t.ppf(1 - alpha / 2, n - 1))
    lo, hi = float(diff.mean() - t_crit * se), float(diff.mean() + t_crit * se)
    dz = float(diff.mean() / sd) if sd > 0 else np.nan
    drift.append({"from_version": a, "to_version": b, "items": n,
                  "mean_change": round(float(diff.mean()), 4),
                  "ci_lo": round(lo, 4), "ci_hi": round(hi, 4),
                  "alpha_bonferroni": round(alpha, 4),
                  "cohens_dz": round(dz, 4),
                  "alert_threshold": 0.5,
                  "alert_triggered": bool(abs(dz) >= 0.5),
                  "interval_includes_zero": bool(lo < 0 < hi)})

three_rows = []
for label, filename in THREE.items():
    d = pd.read_csv(RAW / filename)
    if label == "Opus 4.8" and "modelo" in d.columns:
        d = d[d.modelo == "claude-opus-4-8"]
    ok3 = d[d.estado_parseo == "ok"]
    for (item_id, principle), g in ok3.groupby(["item_id", "principio_elegido"]):
        three_rows.append({"system": label, "item_id": item_id,
                           "principle": principle, "generations": len(g)})

pd.DataFrame(integrity).to_csv(RESULTS / "ola2_integrity.csv", index=False)
pd.DataFrame(estimates).to_csv(RESULTS / "ola2_system_estimates.csv", index=False)
pd.DataFrame(per_dilemma).to_csv(RESULTS / "ola2_by_dilemma.csv", index=False)
pd.DataFrame(drift).to_csv(RESULTS / "ola2_version_change.csv", index=False)
pd.DataFrame(three_rows).to_csv(RESULTS / "ola2_three_option_counts.csv", index=False)

print(pd.DataFrame(estimates).to_string(index=False))
print()
print(pd.DataFrame(drift).to_string(index=False))
