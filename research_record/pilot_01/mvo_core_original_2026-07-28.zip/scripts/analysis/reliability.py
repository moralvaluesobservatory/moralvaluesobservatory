"""Reliability of the measurement itself.

Three quantities that most value-evaluation work does not report:

  1. Effective sample size. Repeated generations are not independent
     observations. We report the intraclass correlation, the design effect and
     the resulting effective n, so that no downstream claim silently uses row
     counts as sample size.

  2. Determinism. The share of items where every repetition returned an
     identical value. At temperature 0 this is high, which is informative in
     itself: the system is not sampling from a distribution of positions, it is
     emitting one position.

  3. Variant stability. The same instrument administered in four prompt
     formats. Any claim that changes when the format changes is a claim about
     the prompt, not about the system.
"""
from __future__ import annotations
import numpy as np
import pandas as pd
from common import (ROOT, RESULTS, FOUNDATIONS, FOUNDATION_MAP,
                    icc_design_effect, profile_correlation)

OLA2 = ROOT / "data/raw/ola2"
MFQ_EN = ROOT / "data/raw/mfq/english"
HUMAN = pd.read_csv(ROOT / "data/reference/mfq2_human_reference_frame.csv")

SYSTEMS = {"Opus 4.8": ("opus.csv", "claude-opus-4-8"), "GPT 5.5": ("gpt.csv", None),
           "DeepSeek v4 Pro": ("deepseek.csv", None), "GLM 5.2": ("glm.csv", None),
           "Fable 5": ("fable.csv", None)}
MFQ_SYSTEMS = {"Opus 4.8": ("opus_generations.csv", "opus-4.8"), "GPT 5.5": ("gpt.csv", None),
               "DeepSeek v4 Pro": ("deepseek.csv", None), "GLM 5.2": ("glm.csv", None),
               "Fable 5": ("fable.csv", None)}
VARIANTS = ["lente_A", "canonica", "lente_B", "lente_C"]


def load_ola2(filename, model):
    d = pd.read_csv(OLA2 / filename)
    d = d[d.estado_parseo == "ok"].copy()
    if model and "modelo" in d.columns:
        d = d[d.modelo == model]
    d["value_num"] = pd.to_numeric(d.valor, errors="coerce")
    return d


def load_mfq(filename, model=None, variant=None):
    d = pd.read_csv(MFQ_EN / filename)
    d = d[d.estado_parseo == "ok"].copy()
    if model and "modelo" in d.columns:
        d = d[d.modelo == model]
    if variant and "variante" in d.columns:
        d = d[d.variante == variant]
    d["score"] = pd.to_numeric(d.score, errors="coerce")
    d["foundation_name"] = d.fundamento.map(FOUNDATION_MAP)
    return d


# ---------------------------------------------------------------- effective n
rows = []
for label, (fn, model) in SYSTEMS.items():
    d = load_ola2(fn, model)
    scale = d[d.formato == "escala"].dropna(subset=["value_num"])
    icc, deff, m, n_eff = icc_design_effect(scale, "item_id", "value_num")
    per_item_sd = scale.groupby("item_id").value_num.std(ddof=0)
    rows.append({"system": label, "instrument": "ola2_scale",
                 "rows": len(scale), "clusters": scale.item_id.nunique(),
                 "repetitions_per_cluster": round(m, 2), "icc": round(icc, 4),
                 "design_effect": round(deff, 2), "effective_n": round(n_eff, 1),
                 "deterministic_clusters": int((per_item_sd == 0).sum()),
                 "deterministic_share": round(float((per_item_sd == 0).mean()), 4)})

for label, (fn, model) in MFQ_SYSTEMS.items():
    d = load_mfq(fn, model=model, variant="canonica").dropna(subset=["score"])
    if d.empty:
        continue
    icc, deff, m, n_eff = icc_design_effect(d, "item_id", "score")
    per_item_sd = d.groupby("item_id").score.std(ddof=0)
    rows.append({"system": label, "instrument": "mfq2_canonical_variant",
                 "rows": len(d), "clusters": d.item_id.nunique(),
                 "repetitions_per_cluster": round(m, 2), "icc": round(icc, 4),
                 "design_effect": round(deff, 2), "effective_n": round(n_eff, 1),
                 "deterministic_clusters": int((per_item_sd == 0).sum()),
                 "deterministic_share": round(float((per_item_sd == 0).mean()), 4)})

effective = pd.DataFrame(rows)
effective.to_csv(RESULTS / "reliability_effective_n.csv", index=False)

# ------------------------------------------------------- variant instability
stability = []
for label, (fn, model) in MFQ_SYSTEMS.items():
    nearest = {}
    for variant in VARIANTS:
        d = load_mfq(fn, model=model, variant=variant)
        if d.empty:
            continue
        p = d.groupby("foundation_name").score.mean().reindex(FOUNDATIONS).to_numpy()
        cors = sorted(((r.country, profile_correlation(p, r[FOUNDATIONS].astype(float).to_numpy()))
                       for _, r in HUMAN.iterrows()), key=lambda x: x[1], reverse=True)
        nearest[variant] = cors[0]
    if not nearest:
        continue
    countries = [v[0] for v in nearest.values()]
    top = nearest.get("canonica") or list(nearest.values())[0]
    row = {"system": label, "distinct_nearest_countries": len(set(countries)),
           "stable_across_variants": len(set(countries)) == 1,
           "countries_observed": "|".join(sorted(set(countries)))}
    for variant in VARIANTS:
        row[f"nearest_{variant}"] = nearest.get(variant, (None, None))[0]
    stability.append(row)

stability_df = pd.DataFrame(stability)
stability_df.to_csv(RESULTS / "reliability_variant_stability.csv", index=False)

# --------------------------------------- which countries survive as a *set*
sets = []
for label, (fn, model) in MFQ_SYSTEMS.items():
    counts = {}
    for variant in VARIANTS:
        d = load_mfq(fn, model=model, variant=variant)
        if d.empty:
            continue
        p = d.groupby("foundation_name").score.mean().reindex(FOUNDATIONS).to_numpy()
        cors = sorted(((r.country, profile_correlation(p, r[FOUNDATIONS].astype(float).to_numpy()))
                       for _, r in HUMAN.iterrows()), key=lambda x: x[1], reverse=True)
        for country, _ in cors[:3]:
            counts[country] = counts.get(country, 0) + 1
    for country, hits in sorted(counts.items(), key=lambda x: -x[1]):
        sets.append({"system": label, "country": country, "top3_appearances": hits,
                     "of_variants": len([v for v in VARIANTS])})
pd.DataFrame(sets).to_csv(RESULTS / "reliability_nearest_country_set.csv", index=False)

print(effective.to_string(index=False))
print()
print(stability_df.to_string(index=False))
