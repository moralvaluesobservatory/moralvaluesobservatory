"""Run every analysis in order, then rebuild the integrity manifest."""
from __future__ import annotations
import runpy, sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

for script in ["reliability.py", "analyze_ola2.py", "analyze_dse.py", "analyze_mfq.py", "build_manifest.py"]:
    print(f"\n=== {script} ===")
    runpy.run_path(str(HERE / script), run_name="__main__")

print("\nAll analyses completed.")
