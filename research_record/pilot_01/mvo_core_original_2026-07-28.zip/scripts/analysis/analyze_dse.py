"""Allocation task: where systems fall relative to the human range.

The central output is not a ranking of systems. It is `dse_human_range.csv`:
for each system, whether its allocation behaviour falls inside or outside the
interval in which the published human samples actually fall.

All intervals resample whole scenarios (`set_id`), never rows.
"""
from __future__ import annotations
import numpy as np
import pandas as pd
from common import ROOT, RESULTS, SEED, cluster_bootstrap_mean, ci95, range_position

RAW = ROOT / "data/raw/dse"
FILES = sorted(RAW.glob("dse_*_20*.csv"))
HUMAN = pd.read_csv(ROOT / "data/reference/human_dse_reference_registry.csv")
B_COEF = 600

DUMMIES_WORK = {"performance_medium": ("desemp", "2"), "performance_high": ("desemp", "3"),
                "dedication_medium": ("dedic", "2"), "dedication_high": ("dedic", "3"),
                "tenure_8": ("anos", "8"), "tenure_16": ("anos", "16"), "female": ("genero", "f"),
                "name_slavic": ("origen", "eslavo"), "name_arabic": ("origen", "arabe"),
                "two_children": ("hijos", "2"), "poor_health": ("salud", "2"), "single": ("pareja", "2")}
DUMMIES_FAMILY = {"financial_tight": ("finanzas", "2"), "two_children": ("hijos", "2"),
                  "poor_health": ("salud", "2"), "single": ("pareja", "2"),
                  "attention_high": ("atencion", "3"), "attention_medium": ("atencion", "2"),
                  "female": ("genero", "f")}


def gini3(values):
    s = np.sort(np.asarray(values, float)); total = s.sum()
    if total <= 0:
        return np.nan
    n = len(s)
    return float(np.sum((2 * np.arange(1, n + 1) - n - 1) * s) / (n * total))


def attrs(profile):
    return dict(part.split("=", 1) for part in profile.split(";") if "=" in part)


def design(df, dummies):
    out = []
    for _, r in df.iterrows():
        X, Y = [], []
        for i in (1, 2, 3):
            a = attrs(r[f"perfil_{i}"])
            X.append([1.0 if a.get(k) == v else 0.0 for k, v in dummies.values()])
            Y.append(float(r[f"share_{i}"]) - 1 / 3)
        X = np.asarray(X); Y = np.asarray(Y)
        out.append((X - X.mean(axis=0), Y - Y.mean()))
    return out


def fit(dec):
    X = np.vstack([x for x, _ in dec]); y = np.concatenate([y for _, y in dec])
    return np.linalg.lstsq(X, y, rcond=None)[0]


def equal_split_flag(df):
    return (np.isclose(df.share_1, 1 / 3) & np.isclose(df.share_2, 1 / 3) & np.isclose(df.share_3, 1 / 3))


# ---------------------------------------------------- human reference ranges
human = HUMAN[HUMAN.record_type == "exact_equal_split_rate"].copy()
human["value"] = pd.to_numeric(human.estimate, errors="coerce")
human_ranges = {}
for situation, key in [("inheritance/family", "familia"), ("work/bonus", "trabajo")]:
    v = human[human.situation == situation].value.dropna()
    if len(v):
        human_ranges[key] = {"lo": float(v.min()), "hi": float(v.max()),
                             "n_values": int(len(v)),
                             "n_samples": int(human[human.situation == situation]["sample"].nunique())}

integrity, equal_rows, range_rows, gini_rows, coef_rows = [], [], [], [], []

for file_index, path in enumerate(FILES):
    d = pd.read_csv(path)
    model = str(d.modelo.iloc[0])
    usable = d[d.estado_parseo.isin(["ok", "ajustado"])].copy()
    amount_sum = usable[["monto_1", "monto_2", "monto_3"]].sum(axis=1)
    share_sum = usable[["share_1", "share_2", "share_3"]].sum(axis=1)
    integrity.append({
        "dataset": path.name, "model": model, "rows": len(d), "usable": len(usable),
        "usable_rate": round(len(usable) / len(d), 6),
        "scenarios": int(usable.set_id.nunique()),
        "amount_sum_failures": int((~np.isclose(amount_sum, 18000)).sum()),
        "share_sum_failures": int((~np.isclose(share_sum, 1.0)).sum()),
        "negative_amount_rows": int((usable[["monto_1", "monto_2", "monto_3"]] < 0).any(axis=1).sum()),
        "duplicate_decision_rows": int(d.duplicated(["situacion", "set_id", "repeticion"]).sum())})

    for situation in ["trabajo", "familia"]:
        x = usable[usable.situacion == situation].copy()
        if x.empty:
            continue
        x["equal"] = equal_split_flag(x)
        observed = float(x.equal.mean() * 100)
        boot = cluster_bootstrap_mean(x, "set_id", "equal", seed=SEED + file_index) * 100
        lo, hi = ci95(boot)
        equal_rows.append({"model": model, "situation": situation, "rows": len(x),
                           "scenarios": int(x.set_id.nunique()),
                           "equal_split_pct": round(observed, 3),
                           "ci_lo": round(lo, 3), "ci_hi": round(hi, 3)})
        hr = human_ranges.get(situation)
        if hr:
            range_rows.append({
                "model": model, "situation": situation,
                "model_pct": round(observed, 3),
                "model_ci_lo": round(lo, 3), "model_ci_hi": round(hi, 3),
                "human_range_lo": hr["lo"], "human_range_hi": hr["hi"],
                "human_values": hr["n_values"], "human_samples": hr["n_samples"],
                "position": range_position(observed, hr["lo"], hr["hi"]),
                "intervals_overlap": bool(hi >= hr["lo"] and lo <= hr["hi"]),
                "gap_to_nearest_human_bound": round(min(abs(hi - hr["lo"]), abs(lo - hr["hi"])), 3)
                if not (hi >= hr["lo"] and lo <= hr["hi"]) else 0.0})

    work = usable[usable.situacion == "trabajo"].copy()
    work["gini"] = work.apply(lambda r: gini3([r.share_1, r.share_2, r.share_3]), axis=1)
    boot = cluster_bootstrap_mean(work.dropna(subset=["gini"]), "set_id", "gini", seed=SEED + file_index)
    lo, hi = ci95(boot)
    gini_rows.append({"model": model, "situation": "trabajo",
                      "gini_mean": round(float(work.gini.mean()), 6),
                      "ci_lo": round(lo, 6), "ci_hi": round(hi, 6),
                      "scenarios": int(work.set_id.nunique())})

    rng = np.random.default_rng(SEED + file_index)
    for situation, dummies in [("trabajo", DUMMIES_WORK), ("familia", DUMMIES_FAMILY)]:
        sub = usable[usable.situacion == situation]
        if sub.empty:
            continue
        scenario_ids = sub.set_id.unique()
        by_scenario = {}
        for k, g in sub.groupby("set_id"):
            dec = design(g, dummies)
            by_scenario[k] = (np.vstack([x for x, _ in dec]), np.concatenate([y for _, y in dec]))
        Xall = np.vstack([v[0] for v in by_scenario.values()])
        Yall = np.concatenate([v[1] for v in by_scenario.values()])
        beta = np.linalg.lstsq(Xall, Yall, rcond=None)[0] * 100
        boots = []
        for _ in range(B_COEF):
            picked = rng.choice(scenario_ids, size=len(scenario_ids), replace=True)
            Xb = np.vstack([by_scenario[k][0] for k in picked])
            Yb = np.concatenate([by_scenario[k][1] for k in picked])
            try:
                boots.append(np.linalg.lstsq(Xb, Yb, rcond=None)[0] * 100)
            except Exception:
                continue
        boots = np.asarray(boots)
        for j, name in enumerate(dummies):
            lo, hi = np.percentile(boots[:, j], [2.5, 97.5])
            coef_rows.append({"model": model, "situation": situation, "variable": name,
                              "beta_pp": round(float(beta[j]), 4),
                              "ci_lo": round(float(lo), 4), "ci_hi": round(float(hi), 4),
                              "excludes_zero": bool(lo > 0 or hi < 0)})

pd.DataFrame(integrity).to_csv(RESULTS / "dse_integrity.csv", index=False)
pd.DataFrame(equal_rows).to_csv(RESULTS / "dse_equal_split.csv", index=False)
pd.DataFrame(range_rows).to_csv(RESULTS / "dse_human_range.csv", index=False)
pd.DataFrame(gini_rows).to_csv(RESULTS / "dse_gini.csv", index=False)
pd.DataFrame(coef_rows).to_csv(RESULTS / "dse_coefficients.csv", index=False)

print(pd.DataFrame(range_rows).to_string(index=False))
