"""Shared utilities.

Design note. Repeated generations of the same item or scenario are not
independent observations: intraclass correlation in this data runs from 0.75
to 0.94, so a nominal 570 rows carry roughly 57 units of information. Every
interval in this repository is therefore produced by resampling whole clusters
(items, scenarios), never rows.
"""
from __future__ import annotations
from pathlib import Path
import hashlib
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[2]
DATA = ROOT / "data"
RESULTS = DATA / "results"
RESULTS.mkdir(parents=True, exist_ok=True)

FOUNDATIONS = ["Care", "Equality", "Proportionality", "Loyalty", "Authority", "Purity"]
FOUNDATION_MAP = {"CARE": "Care", "EQUA": "Equality", "PROP": "Proportionality",
                  "LOYA": "Loyalty", "AUTH": "Authority", "PURI": "Purity"}
BOOTSTRAP_REPLICATES = 10000
SEED = 20260728


def zscore(v):
    v = np.asarray(v, dtype=float)
    sd = v.std(ddof=0)
    return np.zeros_like(v) if sd == 0 else (v - v.mean()) / sd


def profile_correlation(a, b):
    a = np.asarray(a, dtype=float); b = np.asarray(b, dtype=float)
    if np.allclose(a, a[0]) or np.allclose(b, b[0]):
        return np.nan
    return float(np.corrcoef(a - a.mean(), b - b.mean())[0, 1])


def sha256_file(path: Path):
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def icc_design_effect(df, cluster_col, value_col):
    """Intraclass correlation and design effect for equal-sized clusters."""
    g = df.groupby(cluster_col)[value_col]
    m = float(g.size().mean())
    var_within = float(g.var(ddof=1).mean())
    var_between_obs = float(g.mean().var(ddof=1))
    var_between = max(var_between_obs - var_within / m, 0.0)
    denom = var_between + var_within
    icc = var_between / denom if denom > 0 else np.nan
    deff = 1 + (m - 1) * icc
    n_eff = len(df) / deff if deff and deff > 0 else np.nan
    return icc, deff, m, n_eff


def cluster_bootstrap(df, cluster_col, statistic, replicates=BOOTSTRAP_REPLICATES, seed=SEED):
    """Resample whole clusters with replacement; return the bootstrap distribution."""
    rng = np.random.default_rng(seed)
    groups = [g for _, g in df.groupby(cluster_col)]
    n = len(groups)
    out = []
    for _ in range(replicates):
        idx = rng.integers(0, n, n)
        sample = pd.concat([groups[i] for i in idx], ignore_index=True)
        try:
            value = statistic(sample)
        except Exception:
            continue
        if value is not None and not (isinstance(value, float) and np.isnan(value)):
            out.append(value)
    return np.asarray(out, dtype=float)


def ci95(distribution):
    if len(distribution) == 0:
        return (float("nan"), float("nan"))
    lo, hi = np.percentile(distribution, [2.5, 97.5])
    return float(lo), float(hi)


def range_position(value, lo, hi):
    """Where an estimate sits relative to a human range: below / within / above.

    This is the core comparison of the observatory: not distance to a mean, but
    whether the system falls inside the interval where the population lives.
    """
    if any(np.isnan([value, lo, hi])):
        return "undetermined"
    if value < lo:
        return "below"
    if value > hi:
        return "above"
    return "within"


def cluster_bootstrap_mean(df, cluster_col, value_col, replicates=BOOTSTRAP_REPLICATES, seed=SEED):
    """Fast cluster bootstrap for a mean.

    Resamples whole clusters with replacement and recomputes the overall mean
    from cluster-level sums and counts, which is equivalent to concatenating
    the resampled clusters but orders of magnitude faster.
    """
    g = df.groupby(cluster_col)[value_col]
    sums = g.sum().to_numpy(dtype=float)
    counts = g.count().to_numpy(dtype=float)
    n = len(sums)
    rng = np.random.default_rng(seed)
    idx = rng.integers(0, n, size=(replicates, n))
    return sums[idx].sum(axis=1) / counts[idx].sum(axis=1)
