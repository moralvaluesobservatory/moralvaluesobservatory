# Collection-code policy

The original collection notebooks are retained in `provenance/original_notebooks/` to document what was run. They are not the analytical source of truth.

For Ola 2, the complete Meindl-derived prompt file is deliberately absent from this public repository. A local private file may be checked with `validate_private_meindl_file.py` against the expected item identifiers and SHA-256 hashes. Do not commit that private file.

Original persistent Ola 2 notebooks are available for all five families in `provenance/original_notebooks/ola2/`:

- GPT 5.5 (`GPT_ola2.ipynb`)
- GLM 5.2 (`GLM_ola2.ipynb`)
- Claude Fable 5 (`Fable_ola2.ipynb`)
- Claude Opus, snapshots 4.5 to 4.8 (`Opus_ola2.ipynb`)
- DeepSeek (`DeepSeek_ola2.ipynb`)

Original persistent DSE notebooks are likewise retained for the five families in `provenance/original_notebooks/dse/`. The DeepSeek DSE notebook contains earlier trial cells that used `deepseek-chat`; the final full-collection cells and the raw output file correspond to `deepseek-v4-pro`. An automated test (`test_all_ola2_original_notebooks_present`) verifies that the five Ola 2 notebooks remain in place.
