# Collection-code provenance

## DSE

| File | Block | Exact final system setting recovered |
|---|---|---|
| `DSE_claude_en.ipynb` | DSE Opus | `claude-opus-4-8`, 72 work sets, 32 family sets, 10 repetitions, temperature 1.0, CHF 18,000 |
| `DSE_deepseek_EN.ipynb` | DSE DeepSeek | final complete cells use `deepseek-v4-pro`, temperature 1.0 and a 4,000-token output allowance |
| `DSE_gpt_en.ipynb` | DSE GPT | `gpt-5.5`, 72/32 sets, 10 repetitions, temperature 1.0 |
| `DSE_glm_en.ipynb` | DSE GLM | `glm-5.2`, parallelized complete run |
| `DSE_fable_en.ipynb` | DSE Fable | `claude-fable-5`, parallelized complete run |

The DeepSeek notebook contains earlier tests using `deepseek-chat`; those test cells are not treated as the final DSE collection configuration. The raw output file and final complete-run cells identify `deepseek-v4-pro`.

## Ola 2

| File | Original collection design recovered |
|---|---|
| `GPT_ola2.ipynb` | GPT 5.5, low/high reasoning, 65 items × 10 repetitions; three-option extension. |
| `GLM_ola2.ipynb` | GLM 5.2, xhigh mode, 65 items × 10 repetitions; three-option extension. |
| `Fable_ola2.ipynb` | Claude Fable 5, 65 items × 10 repetitions; three-option extension. |
| `Opus_ola2.ipynb` | Four snapshots (`claude-opus-4-5` to `claude-opus-4-8`), 65 items × 10 repetitions. Temperature 1.0 for 4.5/4.6 and provider default for 4.7/4.8; three-option extension. |
| `DeepSeek_ola2.ipynb` | Two modes: API `deepseek-chat` (`non_thinking`) and `deepseek-reasoner` (`thinking`), recorded under the project family label `deepseek-v4-pro`; 65 items × 10 repetitions per mode; three-option extension. |

All five original persistent Ola 2 notebooks are now retained under `provenance/original_notebooks/ola2/`. The public repository still does not redistribute the private Meindl item wording required to rerun them.
