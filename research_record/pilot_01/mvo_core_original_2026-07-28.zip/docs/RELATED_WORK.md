# Related work

This observatory does not claim priority. The field is active and several
lines of work overlap directly with what is measured here. Listing them is
part of the record.

## Instruments applied to language models

Moral Foundations instruments have been administered to language models since
2023, including work comparing model profiles against human political and
demographic groups, and work applying the MFQ-2 across cultural contexts
rather than political ideologies. A systematic review of language-model
psychometrics catalogues this literature.

**Overlap with this project:** the instrument and the comparison to human
group means. **Difference:** page-level provenance for every human value, and
comparison expressed as range position rather than distance to a mean.

## Abstract ratings versus concrete judgments

Work contrasting Moral Foundations Questionnaire responses with Moral
Foundations Vignettes has characterised conflicts between the two as
inconsistency.

**Overlap:** structurally the same contrast this project attempted between
stated criteria and dilemma choices. **Status here:** withdrawn as
unsupported at our sample size (see `WITHDRAWN.md` §1).

## Value evaluation platforms

Platforms exist that evaluate model values against several value systems at
once, including Schwartz basic values and Moral Foundations Theory, with
generated items to resist contamination.

**Difference:** those are evaluation platforms producing scores against value
targets; this is a dated record of position relative to human populations.

## Preference dashboards

Public dashboards report which people, companies and countries models value
most.

**Difference:** a different construct — relative preference over entities
rather than distributive criteria — and no human comparison samples.

## Consumer-facing comparison

At least one public quiz compares a visitor's own answers on a large set of
moral dilemmas against many models.

**Difference:** the comparison target is the individual visitor, not a
published population sample.

## Longitudinal behaviour

Drift across model versions has been documented for reasoning and
instruction-following, for trustworthiness benchmarks across successive
checkpoints, for multimodal safety, and specifically for moral values across
model generations.

**Overlap:** direct. **Difference:** those are papers, frozen at publication;
this is maintained infrastructure. One of them argues explicitly that a trust
score should be reported as a dated, checkpoint-bound artefact rather than
carried forward — which is the case for building this as infrastructure rather
than as a finding.

## Validity criticism this project accepts

Published work reports that model responses on some foundations differ from
any studied human group in ways suggesting the instrument does not transfer
cleanly, and that prompting method significantly changes responses. Our own
variant analysis reproduces the second point: verdicts change with prompt
format for most foundations, and we publish that dependence rather than
selecting a favourable variant.
