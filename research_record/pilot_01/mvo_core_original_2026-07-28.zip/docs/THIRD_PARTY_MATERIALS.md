# Third-party materials and redistribution

The Meindl article and supplementary material are source documents, not repository assets. No express permission to redistribute the complete instrument was available. Therefore:

- the article and supplement are not included;
- the private 65-item administration CSV is not included;
- collection templates do not embed the complete item text;
- the public registry contains hashes and source locations only;
- raw model responses and project-generated metadata/results are retained.

This repository does not assert that the source instrument is open licensed. Users must obtain and use the source material under applicable terms.

## Gilgen book

The Gilgen (2022) book is cited as the source of the human comparison values and is not included in the repository. The machine-readable registry transcribes only numerical findings and source locations needed to support the comparison; it does not reproduce the book.
