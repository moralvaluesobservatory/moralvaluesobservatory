# Open items

## Blocking, before any claim about representation

1. **Human microdata.** Range position and compression both need population
   distributions, not means. The 19-country frame provides only means. Next
   acquisition: value-survey microdata covering redistribution versus
   incentives, which extends the existing axis from 19 countries to a much
   wider set and provides demographic subgroups for the first time.
2. **Licence verification for that microdata.** These archives are typically
   free but require registration, mandatory citation, and often forbid
   redistribution of the original files. Only derived statistics could be
   published under our own licence. Verify before building on top.

## Known limitations not fixed by reanalysis

3. **Construct validity.** The MFQ-2 was validated on humans. Measurement
   invariance between humans and language models is not established, and
   published work reports foundations where model responses differ from any
   human group in structure, not only in level.
4. **Mode mismatch.** Human reference values come from surveys of people;
   model values come from prompting an API. The response processes are not the
   same and the comparison rests on that seam.
5. **Five systems.** Any statement about systems as a class rests on five
   points.

## Provenance

6. **Gilgen (2022) internal discrepancy.** Prose on p. 111 and Figure 4.9 on
   p. 117 cannot be reconciled from the published text. A written inquiry to
   the author is in preparation. Both values are published with the
   qualification; no single Swiss anchor is used. See
   `SOURCE_DISCREPANCY_GILGEN_2022.md`.

## Institutional

7. **Independent human review.** Not yet obtained. The repository is
   structured so that a reviewer can inspect instruments, raw outputs,
   transformations and limitations without relying on claims made by the
   project.
8. **ORCID** for the author, and a versioned release with a DOI.
