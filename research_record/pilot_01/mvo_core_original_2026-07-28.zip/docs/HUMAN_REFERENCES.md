# Human DSE reference values

## Source

Sandra Gilgen (2022), *Disentangling Justice: Needs, Equality or Merit? On the Situation-Dependency of Distributive Justice*. Nomos. DOI: `10.5771/9783748926955`.

The book is the source of the human comparison values. The 2025 Gilgen and Zangger article is used only for the later workplace DSE description and is not substituted for the book's student and inheritance results. The book itself is not redistributed in this repository.

## Values used

- Work exact-equal splits, page 134, Figure 4.21: Bern students 29% overall; Princeton students 17% overall. The book also reports Bern women 30%, Bern men 26%, Princeton women 18%, and Princeton men 15%.
- Family exact-equal splits, page 135, Figure 4.22: Bern women 73%, Bern men 62%, Princeton women 59%, and Princeton men 46%. **The book does not report combined family percentages for either university.**
- Swiss general-population family result, page 111: the prose says “roughly 60%” equal splits. Page 117, Figure 4.9, separately reports 74% for women and 68% for men. These statements are internally inconsistent if interpreted as the same exact statistic. The repository publishes both with a warning and does not turn either into a single exact Swiss anchor.
- Swiss family attribute effects, page 111, Figure 4.5 and accompanying text: two children +3 percentage points; poor health +2; financial troubles +1; mostly attentive/helpful +5; very attentive/helpful +6.

## Removed values

Earlier website versions displayed 67.5% for Bern and 52.5% for Princeton in the family situation. Those numbers are unweighted arithmetic means of the gender-specific percentages. They are not reported by the book and are not valid overall sample estimates. They have been removed.

## Machine-readable registry

See `data/reference/human_dse_reference_registry.csv`. Every row records the source page, figure/table, sample, subgroup, statistic, unit and qualification.
