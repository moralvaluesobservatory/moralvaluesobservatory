# Instrument provenance

## Meindl distributive-justice material

**Citation:** Meindl, P., Iyer, R., & Graham, J. (2019). *Distributive Justice Beliefs are Guided by Whether People Think the Ultimate Goal of Society is Well-Being or Power*. Basic and Applied Social Psychology, 41(6), 359–385. DOI: 10.1080/01973533.2019.1663524.

The source supplement contains:

- Table S2: seven justice scenarios used as the source for the scenario-rating block and for seven project-created forced binary comparisons.
- Table S3: 36 CDJS items.
- Table S5: the four-rule distribution choice.

The public repository does not redistribute the full wording. `data/metadata/ola2_instrument_registry.csv` records the source location and SHA-256 of every administered text.

**Hash normalization.** The `administered_text_sha256` values are computed over a normalized form of the text, not the raw string: all whitespace runs (including newlines) are collapsed to a single space, curly quotation marks (’ ‘ “ ”) are replaced by their straight equivalents (' and "), and the result is stripped of leading/trailing whitespace before UTF-8 encoding. This is exactly the `norm()` function in `scripts/collection/validate_private_meindl_file.py`, which is the canonical verifier. Hashing the raw text without this normalization will fail to match on items whose wording contains line breaks or typographic quotes.

The option classifications identify which response content represents equality or equity/merit. They are not moral answer keys.

## Naser

No Naser ethical dilemma was administered in the Meindl/Ola 2 block. Naser may be cited only as related work on longitudinal moral-response measurement, not as an instrument source for `DIL_01`–`DIL_07`.

## DSE

The DSE block uses hypothetical allocations of CHF 18,000 in work-bonus and family-inheritance vignettes. The public results cover model responses and structural invariants. Human comparison values from Gilgen (2022) are published in `data/reference/human_dse_reference_registry.csv`, transcribed with page, figure, sample, subgroup, unit and qualification for every entry; see `docs/HUMAN_REFERENCES.md` and `docs/SOURCE_DISCREPANCY_GILGEN_2022.md` for the known internal discrepancy of the source book.

## MFQ-2

The MFQ analysis compares six foundation means against a supplied 19-country reference frame. The four-country project reference is an explicit, unweighted construction and is not a standard published WEIRD index.
