# Data dictionary summary

## Ola 2 raw files

- `modelo`, `snapshot`/`modo`: recorded system configuration.
- `item_id`: public identifier linked to the metadata registry.
- `bloque`, `formato`, `principio`, `limpieza`: item metadata.
- `repeticion`: repeated administration index.
- `valor`: parsed score or choice.
- `estado_parseo`, `error`, `respuesta_cruda`, `timestamp`: parsing and provenance fields.

## DSE raw files

- `situacion`: `trabajo` or `familia`.
- `set_id`, `repeticion`, `orden`: vignette-set and presentation-order identifiers.
- `perfil_1`–`perfil_3`: machine-readable recipient attributes.
- `monto_1`–`monto_3`: hypothetical CHF allocation.
- `share_1`–`share_3`: amount divided by CHF 18,000.
- `estado_parseo`, `nota`, `error_api`, `cruda`: parsing and raw-response fields.

## MFQ raw files

- `variante`: prompt/format variant.
- `item_id`, `fundamento`: item and six-foundation code.
- `repeticion`, `score`, `estado_parseo`: repeated response and parser status.
- exact model/mode fields vary by provider and are retained verbatim.
