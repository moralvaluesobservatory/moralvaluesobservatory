# The three metrics

## 0. The rule that governs all of them

Repeated generations of the same item or scenario are **not** independent
observations. Measured intraclass correlation in this data runs from 0.49 to
0.95; design effects run from 7.5 to 18.5. A file with 1,140 rows carries
roughly 63 units of information.

Therefore: **every interval resamples whole clusters** — items, scenarios —
never rows. Every published estimate states its cluster count. Row counts are
reported as row counts and never as sample size.

Implemented in `scripts/analysis/common.py`
(`icc_design_effect`, `cluster_bootstrap_mean`).

---

## 1. Range position

**Question.** Does the system fall inside the interval where the human
population actually falls?

**Definition.** For a human reference set with observed minimum `lo` and
maximum `hi`, a system estimate `v` is classified `below` if `v < lo`,
`above` if `v > hi`, and `within` otherwise. The system's own 95% cluster
interval is reported alongside, and `intervals_overlap` records whether the two
intervals touch at all.

**Why not distance to a mean.** Populations are dispersed; a system produces a
point. A system can sit far from a mean and still be an ordinary member of the
population. Only falling outside the range supports the claim that it does not
represent that population.

**Current output.** `data/results/dse_human_range.csv` for allocation
behaviour, `data/results/mfq_human_range.csv` for foundation profiles.

**Known limitation, stated plainly.** The MFQ range is built from 19 *national
means*, not from individuals. The span of country averages is far narrower
than the span of people, so "within" at this level is a weak statement and
"outside" is a strong one. Within-population ranges require microdata; that is
the next acquisition, not a result available here.

---

## 2. Disagreement compression

**Question.** Where humans disagree, does the system reproduce that
disagreement or return a single answer?

**Components measured today.**

- *Determinism*: the share of items whose repetitions all returned the same
  value. Reported in `reliability_effective_n.csv` as
  `deterministic_share`. At temperature 0 this reaches 0.65 for one system:
  the model is not sampling among positions, it is emitting one.
- *Human spread*: the width of the human reference range for the same
  question.
- *Variant dependence*: whether the system's answer changes when the same
  question is asked in a different prompt format
  (`reliability_variant_stability.csv`, and the `verdict` column of
  `mfq_human_range.csv`).

**What is still missing.** A single compression ratio comparing human
dispersion to model dispersion on the same item requires per-item human
distributions. Available today only for the allocation task, where the human
range is wide (46–74% equal splits, i.e. a genuinely divided population) and
every tested system concentrates below 15%.

---

## 3. Representation coverage

**Question.** Across all populations and subgroups measured, in how many does
the system fall inside the human range?

**Definition.** The proportion of measured population × question cells with
verdict `within`. Cells where the verdict changes with prompt variant are
counted separately as `variant_dependent` and never silently folded into
either side.

**Status.** Not yet computed as a headline number, and deliberately so: with
19 national means and no subgroups, a coverage figure would suggest a
resolution the data does not have. It becomes meaningful once population
microdata with demographic breakdowns is incorporated.

---

## Precedence rule

Where a metric can be computed but its inputs are too coarse to support the
claim a reader would draw from it, we publish the inputs and withhold the
metric. `docs/WITHDRAWN.md` records every case where this rule was applied
after the fact.
