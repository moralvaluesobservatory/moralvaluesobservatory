# Withdrawn findings

Every claim listed here was previously computed and, in some cases, published.
Each is recorded with what was claimed, why it does not hold, and what replaced
it. Nothing here was removed quietly.

Date of this review: 28 July 2026. Cause: reanalysis after establishing that
repeated generations had been treated as independent observations.

---

## 1. The declared-versus-chosen correlation

**Claimed.** An inverse relationship (r = −0.30) between how strongly a system
rates proportionality over equality and how often it chooses the proportional
option in dilemmas.

**Why it does not hold.** The correlation was computed across five aggregated
points, one per model family. With n = 5 the 95% interval runs from −0.935 to
+0.792 and an exact permutation test over all 120 orderings gives p = 0.60. A
leave-one-item-out analysis had already shown the value collapsing to +0.06
when one dilemma was omitted; the deeper problem is that five points cannot
support the claim in either direction.

**Replaced by.** Nothing. The question is open and the current design cannot
answer it. Separating five systems on this relationship would require either
many more systems or a within-system design.

**Removed:** `ola2_declared_vs_chosen.csv`, `ola2_leave_one_item_out.csv`.
**Guarded by:** `test_withdrawn_correlation_is_not_recomputed`.

---

## 2. A nearest human population per system

**Claimed.** Each system's closest national-mean profile: Ireland for two
systems, New Zealand for two, Switzerland for one.

**Why it does not hold.** The published figure used one of four prompt
variants. **None of the five systems keeps the same nearest country across the
four variants.** The profile-correlation gap between first and second place
ranges from 0.0018 to 0.0254, well inside the variation the format itself
introduces.

**Replaced by.** Two things: the *set* of candidate countries, which is stable
(Ireland, Switzerland, New Zealand, Belgium — the same egalitarian-WEIRD
cluster), in `reliability_nearest_country_set.csv`; and the range-position
verdict per foundation in `mfq_human_range.csv`, which marks a foundation
`variant_dependent` whenever the verdict is not stable across all four
variants.

**Removed:** `mfq_reference_profile.csv`.
**Guarded by:** `test_no_single_nearest_country_per_system`.

---

## 3. Ordering systems by proportional choice

**Claimed.** Systems differ in how often they choose the proportional option
(0.43 for the lowest, 0.59 for the highest).

**Why it does not hold.** There are seven binary dilemmas. With intervals that
resample dilemmas, every system spans roughly 0.14 to 0.87 and all five
intervals overlap each other and include 0.5. The resolution does not exist.

**Replaced by.** The same point estimates, published with their intervals and
with `chosen_interval_width` beside them in `ola2_system_estimates.csv`, so
the width is not separable from the value.

**Guarded by:** `test_dilemma_intervals_are_reported_as_wide`.

---

## 4. Version-to-version drift in Opus

**Claimed.** A detectable change between snapshots, with attention to a dip at
4.5.

**Why it does not hold.** Paired by item (n = 57) and Bonferroni-corrected for
three transitions, every interval includes zero: −0.021 [−0.185, +0.142],
+0.219 [−0.047, +0.485], +0.054 [−0.121, +0.230]. Effect sizes are 0.04, 0.27
and 0.10. **None reaches the |d| ≥ 0.5 alert threshold the protocol itself
set.** The protocol behaved correctly: no alert was warranted and none was
issued.

**Replaced by.** `ola2_version_change.csv`, which reports each transition with
its interval, its effect size, the threshold and an explicit
`alert_triggered` flag.

**Guarded by:** `test_version_change_reports_threshold_and_no_alert`.

---

## 5. Row counts presented as sample size

**Claimed.** Figures such as "5,200 allocation decisions" and per-system counts
in the hundreds, in positions where a reader would read them as sample size.

**Why it does not hold.** Those are generation counts. Effective sample sizes,
after accounting for intraclass correlation, are 38–74 depending on system and
instrument.

**Replaced by.** `reliability_effective_n.csv`, and a rule that every estimate
publishes its cluster count.

**Guarded by:** `test_every_estimate_reports_clusters_not_rows`,
`test_effective_n_is_reported_and_below_row_count`.

---

## What survived the same reanalysis

Recorded here so the list is not read as a retraction of everything.

- **Allocation behaviour against the human range.** In both the work-bonus and
  the inheritance task, all five systems fall **below** the published human
  range of exact equal splits, with no interval overlap. The largest model
  interval reaches 23.8% against a human range starting at 46% in the family
  task, and 13.4% against a human range starting at 15% in the work task.
- **The direction of stated criteria** for three of five systems, whose
  intervals exclude zero.
- **The task contrast**: merit rewarded in the work scenario, need prioritised
  in the inheritance scenario.
