# Mission

The Moral Values Observatory is a research effort contributing to pluralistic
AI governance. It makes visible **which values and distributive criteria AI
systems express and apply, which human populations they resemble, which
disagreements they compress, whom they represent worst, and how all of this
changes across versions, languages and tasks.**

## What that commits us to

**Comparison against ranges, not means.** A system does not fail to represent a
population by differing from its average. It fails to represent it by falling
outside the interval in which that population actually falls. Every comparison
in this repository is stated as *below*, *within* or *above* a human range,
with the interval attached.

**Compression as a measurable object.** Where humans disagree, a system that
returns one position every time is not neutral: it is compressing a live
disagreement into a single answer. Repetitions and prompt variants are how we
measure that, not noise to be averaged away.

**Provenance for every human number.** Each human reference value carries its
source, page and figure. Where a source contradicts itself, the contradiction
is published rather than resolved silently.

**Dated, versioned, reproducible.** Findings are checkpoint-bound artefacts.
Anything that changes when the prompt format changes is reported as a property
of the format, not of the system.

## The line we do not cross

The observatory measures. It does not demonstrate downstream social
consequence, and it does not by itself produce more representation. Those are
the reasons the measurement matters, stated as aspiration, not as result. The
distinction is structural and appears throughout the documentation:

- **What we measure and can assert:** expressed values, allocation behaviour,
  position relative to human ranges, stability across versions and formats.
- **What we inform but do not demonstrate:** that these patterns affect
  outcomes for the populations concerned, and that documenting them helps
  close the gap.

## What this is not

Not a ranking of models. Not an alignment score. Not a claim that any human
population holds the correct position. Where our resolution is too coarse to
separate systems, we say so rather than ordering them.

## Related work

This is a crowded field and the observatory does not claim priority over it.
Moral Foundations instruments have been applied to language models since 2023;
abstract ratings have been contrasted with concrete vignette judgments; value
evaluation platforms with multiple value systems exist; dashboards of model
preferences over entities exist; and longitudinal moral drift across model
generations has been published. See `docs/references.bib` and
`docs/RELATED_WORK.md`.

What remains uncommon, and what this repository is for: human reference values
carried with page-level provenance, comparison expressed as range position
rather than distance to a mean, disagreement compression treated as a
quantity, and the whole record maintained as reproducible infrastructure
rather than frozen at publication.
