"""Invariants that must hold before anything is published.

These encode commitments, not preferences: no third-party instrument text is
redistributed, no withdrawn claim reappears, and no interval is ever computed
from row counts.
"""
from __future__ import annotations
import csv
import json
from pathlib import Path

import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
RESULTS = ROOT / "data/results"


# ----------------------------------------------------- third-party material
def test_no_public_instrument_text():
    forbidden = "instrumento_ola2_meindl"
    for path in ROOT.rglob("*"):
        if path.is_file():
            assert forbidden not in path.name, f"private instrument file present: {path}"


def test_registry_has_65_items_and_no_text_column():
    registry = pd.read_csv(ROOT / "data/metadata/ola2_instrument_registry.csv")
    assert len(registry) == 65
    assert not any(column.lower() in {"text", "texto", "item_text"} for column in registry.columns)
    assert registry.administered_text_sha256.notna().all()


def test_instrument_attributed_to_meindl_not_naser():
    registry = pd.read_csv(ROOT / "data/metadata/ola2_instrument_registry.csv")
    authors = " ".join(registry.source_author.dropna().astype(str)).lower()
    assert "meindl" in authors
    assert "naser" not in authors


# ---------------------------------------------------------- withdrawn claims
def test_withdrawn_correlation_is_not_recomputed():
    """The declared-versus-chosen correlation was withdrawn: n = 5, p = 0.60."""
    for path in RESULTS.glob("*.csv"):
        columns = " ".join(pd.read_csv(path, nrows=0).columns).lower()
        assert "five_family_correlation" not in columns, f"withdrawn statistic in {path.name}"
    assert not (RESULTS / "ola2_declared_vs_chosen.csv").exists()
    assert not (RESULTS / "ola2_leave_one_item_out.csv").exists()


def test_no_single_nearest_country_per_system():
    """Nearest country is variant-dependent; only the candidate set is stable."""
    assert not (RESULTS / "mfq_reference_profile.csv").exists()
    for path in RESULTS.glob("*.csv"):
        columns = " ".join(pd.read_csv(path, nrows=0).columns).lower()
        assert "nearest_country" not in columns or "reliability_" in path.name, (
            f"per-system nearest country asserted in {path.name}")


# ------------------------------------------------------ statistical honesty
def test_every_estimate_reports_clusters_not_rows():
    estimates = pd.read_csv(RESULTS / "ola2_system_estimates.csv")
    assert {"declared_items", "chosen_dilemmas"} <= set(estimates.columns)
    assert (estimates.declared_items == 36).all()
    assert (estimates.chosen_dilemmas == 7).all()

    equal = pd.read_csv(RESULTS / "dse_equal_split.csv")
    assert "scenarios" in equal.columns
    assert (equal.scenarios < equal.rows).all(), "scenario count must be below row count"


def test_effective_n_is_reported_and_below_row_count():
    reliability = pd.read_csv(RESULTS / "reliability_effective_n.csv")
    assert len(reliability) > 0
    assert (reliability.effective_n < reliability.rows).all()
    assert (reliability.icc > 0.3).all(), "high ICC is the reason clusters are resampled"


def test_dilemma_intervals_are_reported_as_wide():
    """Seven dilemmas cannot separate systems; the width must stay visible."""
    estimates = pd.read_csv(RESULTS / "ola2_system_estimates.csv")
    assert (estimates.chosen_interval_width > 0.4).all()


def test_version_change_reports_threshold_and_no_alert():
    change = pd.read_csv(RESULTS / "ola2_version_change.csv")
    assert {"cohens_dz", "alert_threshold", "alert_triggered"} <= set(change.columns)
    assert not change.alert_triggered.any(), "no transition reaches the |d| >= 0.5 alert threshold"


# ------------------------------------------------------------- range metric
def test_human_range_comparison_exists_and_is_signed():
    ranges = pd.read_csv(RESULTS / "dse_human_range.csv")
    assert {"position", "intervals_overlap", "human_range_lo", "human_range_hi"} <= set(ranges.columns)
    assert set(ranges.position) <= {"below", "within", "above", "undetermined"}
    assert len(ranges) == 10, "five systems in two situations"


def test_human_reference_registry_keeps_provenance():
    human = pd.read_csv(ROOT / "data/reference/human_dse_reference_registry.csv")
    for column in ["source_id", "doi", "page", "figure_table", "sample", "situation", "record_type"]:
        assert column in human.columns, f"missing provenance column {column}"
    assert human.page.notna().all(), "every human value must carry a page reference"


def test_mfq_range_flags_variant_dependence():
    ranges = pd.read_csv(RESULTS / "mfq_human_range.csv")
    assert {"verdict", "robust_across_variants", "variants_tested"} <= set(ranges.columns)
    assert (ranges.variants_tested == 4).all()
    assert "variant_dependent" in set(ranges.verdict), (
        "variant dependence is a real property of this data and must stay visible")


# ------------------------------------------------------------- provenance
def test_original_notebooks_present():
    notebooks = list((ROOT / "provenance/original_notebooks").rglob("*.ipynb"))
    assert len(notebooks) == 10


def test_notebooks_contain_no_api_keys():
    for path in (ROOT / "provenance/original_notebooks").rglob("*.ipynb"):
        text = json.dumps(json.load(path.open(encoding="utf-8")))
        assert "sk-ant-" not in text and "sk-proj-" not in text


def test_manifest_matches_disk():
    import hashlib
    manifest = ROOT / "data/metadata/file_manifest_sha256.csv"
    with manifest.open(encoding="utf-8") as f:
        rows = list(csv.DictReader(f))
    assert len(rows) > 50
    sample = rows[:: max(len(rows) // 12, 1)]
    for row in sample:
        target = ROOT / row["path"]
        assert target.exists(), f"manifest lists missing file {row['path']}"
        digest = hashlib.sha256(target.read_bytes()).hexdigest()
        assert digest == row["sha256"], f"hash mismatch for {row['path']}"
